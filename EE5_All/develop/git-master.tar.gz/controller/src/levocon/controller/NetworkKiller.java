package levocon.controller;

public class NetworkKiller {

	public void attachKiller(final Process process) {
		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				System.out.println("Shut down!");
				process.destroy();
			}
		});
	}

}