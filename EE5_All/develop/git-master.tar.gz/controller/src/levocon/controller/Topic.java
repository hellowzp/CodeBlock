package levocon.controller;

public class Topic {

	private NetworkHandler nh;
	private int topicId;
	private String topicName;
	// private double value = 0;
	private String message;

	public Topic(NetworkHandler nh, int topicId, String topicName) {
		this.topicId = topicId;
		this.topicName = topicName;
		this.nh = nh;
	}

	public void update() {
		// Get and process latest message
		message = nh.getLatestMessage().getMessage();
		System.out.println("Topic " + topicName + " (" + topicId + ") says: "
				+ message);
	}

}