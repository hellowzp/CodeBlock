package levocon.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public class NetworkHandler implements Runnable {

	private static final String fifoFolder = "tmp";
	private static final String fifoIn = fifoFolder + "/bridgetojava";
	private static final String fifoOut = fifoFolder + "/javatobridge";
	private static final String execPath = "test/fifotest";
	private static final int messageHeaderLength = 16;

	private List<Topic> topics = new ArrayList<Topic>();
	// private String latestMessage;
	private Message latestMessage;

	private Process process;

	public NetworkHandler() {
		init();
	}

	/**
	 * INITIALIZATION Run the C programs, create FIFOs, attach shutdown hooks
	 */
	public void init() {
		Runtime runtime = Runtime.getRuntime();
		try {
			runtime.exec("mkdir " + fifoFolder);
			runtime.exec("mkfifo --mode=0666 " + fifoIn);
			runtime.exec("mkfifo --mode=0666 " + fifoOut);
			process = runtime.exec(execPath);
			NetworkKiller killer = new NetworkKiller();
			killer.attachKiller(process);
		} catch (IOException e) {
			e.printStackTrace();
			System.err.println("Error launching C programs!");
		}
	}

	// DEBUG FUNCTION, TEMPORARY
	public static void main(String[] args) {
		NetworkHandler nh = new NetworkHandler();
		Topic testTopic = new Topic(nh, 1, "Test topic");
		nh.attach(testTopic);
		new Thread(nh).start();
	}

	/**
	 * INCOMING MESSAGES Streams messages from subscribed topics from the FIFO
	 * and notifies topics This is being done in a different thread (cfr:
	 * Runnable)
	 */
	public void run() {
		try {
			// Open FIFO (read sync)
			BufferedInputStream in = new BufferedInputStream(
					new FileInputStream(fifoIn));

			// Declare some local variables
			byte[] header = new byte[messageHeaderLength];
			long address;
			int topicId;
			int messageType;
			boolean clean;
			long length;

			// Stream data from FIFO
			while (true) {
				if (in.available() >= messageHeaderLength) {
					// Get message header;
					in.read(header);
					address = ((header[0] & 0xFF) << 56)
							| ((header[1] & 0xFF) << 48)
							| ((header[2] & 0xFF) << 40)
							| ((header[3] & 0xFF) << 32)
							| ((header[4] & 0xFF) << 24)
							| ((header[5] & 0xFF) << 16)
							| ((header[6] & 0xFF) << 8) | (header[7] & 0xFF);
					topicId = ((header[8] & 0xFF) << 8) | (header[9] & 0xFF);
					messageType = (header[10] & 0xFF);
					clean = ((header[11] & 0xFF) == 1) ? true : false;
					length = ((header[12] & 0xFF) << 32)
							| ((header[13] & 0xFF) << 16)
							| ((header[14] & 0xFF) << 8) | (header[15] & 0xFF);
					latestMessage = new Message(address, topicId, messageType,
							clean, length);

					// Get message body
					byte[] message = new byte[(int) length];
					while (in.available() < length) {
						// Wait till the entire message is available
					}
					in.read(message);
					latestMessage.setMessage(message.toString());

					// Notify topics of new message
					notifyTopics();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			System.err.println("Error streaming messages!");
		}
	}

	/**
	 * INCOMING MESSAGES OBSERVER PATTERN IMPLEMENTATION Getter for the latest
	 * message, called by topics on update
	 * 
	 * @return - The latest message received by the network handler
	 */
	public Message getLatestMessage() {
		return latestMessage;
	}

	/**
	 * INCOMING MESSAGES OBSERVER PATTERN IMPLEMENTATION Allows a topic to
	 * attach itself to update stream
	 * 
	 * @param topic
	 *            - Topic to attach (topic passes itself as argument)
	 */
	public void attach(Topic topic) {
		topics.add(topic);
	}

	/**
	 * INCOMING MESSAGES OBSERVER PATTERN IMPLEMENTATION Calls the update
	 * function of every attached topic
	 */
	public void notifyTopics() {
		for (Topic topic : topics) {
			topic.update();
		}
	}

	/**
	 * OUTGOING MESSAGES Sends a message to the bridge
	 * 
	 * @param message
	 *            - The message to send
	 */
	public void send(Message message) {
		BufferedOutputStream out;
		try {
			// Open FIFO (write sync)
			out = new BufferedOutputStream(new FileOutputStream(fifoOut));

			// Construct the header
			ByteBuffer headerBuffer = ByteBuffer.allocate(messageHeaderLength);
			headerBuffer.putLong(message.getAddress());
			headerBuffer.putShort((short) message.getTopicId());
			headerBuffer.put((byte) message.getMessageType());
			headerBuffer.put((byte) message.getClean());
			headerBuffer.putInt((int) message.getLength());

			// Write the message
			out.write(headerBuffer.array());
			out.write(message.getMessage().getBytes("US-ASCII"));

			// Flush and close
			out.flush();
			out.close();
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
			System.err.println("Error sending message!");
		} catch (IOException e) {
			e.printStackTrace();
			System.err.println("Error sending message!");
		}
	}

	/**
	 * OUTGOING MESSAGES Unsubscribe from a certain topic
	 * 
	 * @param topicId
	 *            - The ID of the topic to unsubscribe from
	 */
	public void subscribe(int topicId) {
		// Pass subscribe command to C bridge
		// send();
	}

	/**
	 * OUTGOING MESSAGES Subscribe to a certain topic
	 * 
	 * @param topicId
	 *            - The ID of the topic to subscribe to
	 */
	public void unsubscribe(int topicId) {
		// Pass unsubscribe command to C bridge
		// send();
	}

}