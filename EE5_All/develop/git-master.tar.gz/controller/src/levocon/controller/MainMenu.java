package levocon.controller;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SpringLayout;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class MainMenu extends JFrame implements ActionListener {

	private static final long serialVersionUID = 5481876836542227705L;
	private JPanel contentPane;
	private JCheckBox chckbxEnableNetwork;
	JButton btnShowDashboard;
	JButton btnShowHistoricData;
	JButton btnManageSensors;
	private JCheckBox chckbxAutoSubscribe;
	private JProgressBar progressBar;
	private JPanel statusBar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainMenu frame = new MainMenu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainMenu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Levocon");

		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		// NORTH WINDOW CONTENT
		chckbxEnableNetwork = new JCheckBox("Enable wireless sensor network");
		chckbxEnableNetwork.setHorizontalAlignment(SwingConstants.TRAILING);
		chckbxEnableNetwork.setActionCommand("network");
		chckbxEnableNetwork.addActionListener(this);
		contentPane.add(chckbxEnableNetwork, BorderLayout.NORTH);

		// SOUTH WINDOW CONTENT
		Box verticalBox = Box.createVerticalBox();
		contentPane.add(verticalBox, BorderLayout.SOUTH);

		progressBar = new JProgressBar();
		progressBar.setString("Connecting...");
		progressBar.setStringPainted(true);
		progressBar.setIndeterminate(true);

		statusBar = new JPanel();
		statusBar.setLayout(new BoxLayout(statusBar, BoxLayout.X_AXIS));

		JLabel lblConnectedSensors = new JLabel("Connected: ");
		statusBar.add(lblConnectedSensors);

		JLabel lblConnectedSensorsNumber = new JLabel("0");
		statusBar.add(lblConnectedSensorsNumber);

		Component strutConnectedSensors = Box.createHorizontalStrut(60);
		statusBar.add(strutConnectedSensors);

		JLabel lblSubscribedSensors = new JLabel("Subscribed: ");
		statusBar.add(lblSubscribedSensors);

		JLabel lblSubscribedSensorsNumber = new JLabel("0");
		statusBar.add(lblSubscribedSensorsNumber);

		Component strutSubscribedSensors = Box.createHorizontalStrut(60);
		statusBar.add(strutSubscribedSensors);

		chckbxAutoSubscribe = new JCheckBox("Auto-subscribe");
		chckbxAutoSubscribe.setActionCommand("network");
		chckbxAutoSubscribe.addActionListener(this);
		statusBar.add(chckbxAutoSubscribe);

		// CENTER WINDOW CONTENT
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		SpringLayout sl_panel = new SpringLayout();
		panel.setLayout(sl_panel);

		btnShowDashboard = new JButton("Show current sensor readings");
		btnShowDashboard.setEnabled(false);
		sl_panel.putConstraint(SpringLayout.NORTH, btnShowDashboard, 46,
				SpringLayout.NORTH, panel);
		sl_panel.putConstraint(SpringLayout.WEST, btnShowDashboard, 0,
				SpringLayout.WEST, panel);
		sl_panel.putConstraint(SpringLayout.EAST, btnShowDashboard, 440,
				SpringLayout.WEST, panel);
		btnShowDashboard.setActionCommand("dashboard");
		btnShowDashboard.addActionListener(this);
		panel.add(btnShowDashboard);

		btnShowHistoricData = new JButton("Show historic data graphs");
		btnShowHistoricData.setEnabled(false);
		sl_panel.putConstraint(SpringLayout.NORTH, btnShowHistoricData, 6,
				SpringLayout.SOUTH, btnShowDashboard);
		sl_panel.putConstraint(SpringLayout.WEST, btnShowHistoricData, 0,
				SpringLayout.WEST, btnShowDashboard);
		sl_panel.putConstraint(SpringLayout.EAST, btnShowHistoricData, 440,
				SpringLayout.WEST, panel);
		btnShowHistoricData.setActionCommand("graphs");
		btnShowHistoricData.addActionListener(this);
		panel.add(btnShowHistoricData);

		btnManageSensors = new JButton("Manage sensors");
		btnManageSensors.setEnabled(false);
		sl_panel.putConstraint(SpringLayout.NORTH, btnManageSensors, 6,
				SpringLayout.SOUTH, btnShowHistoricData);
		sl_panel.putConstraint(SpringLayout.WEST, btnManageSensors, 0,
				SpringLayout.WEST, btnShowDashboard);
		sl_panel.putConstraint(SpringLayout.EAST, btnManageSensors, 0,
				SpringLayout.EAST, btnShowDashboard);
		btnManageSensors.setActionCommand("manage");
		btnManageSensors.addActionListener(this);
		panel.add(btnManageSensors);
	}

	/**
	 * Handle button presses
	 */
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("graphs")) {
			JFrame newWindow = new HistoryActivity();
			newWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			newWindow.pack();
			newWindow.setVisible(true);
		} else if (e.getActionCommand().equals("dashboard")) {
			JFrame newWindow = new DashboardActivity();
			newWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			newWindow.pack();
			newWindow.setVisible(true);
		} else if (e.getActionCommand().equals("network")) {
			toggleNetwork();
		}
	}

	private void toggleNetwork() {
		if (chckbxEnableNetwork.isSelected()) { // Enable network
			btnShowDashboard.setEnabled(true);
			btnShowHistoricData.setEnabled(true);
			btnManageSensors.setEnabled(true);
			contentPane.add(progressBar, BorderLayout.SOUTH);
			contentPane.validate();
			contentPane.repaint();
		} else { // Disable network
			btnShowDashboard.setEnabled(false);
			btnShowHistoricData.setEnabled(false);
			btnManageSensors.setEnabled(false);
			contentPane.remove(progressBar);
			contentPane.remove(statusBar);
			contentPane.validate();
			contentPane.repaint();
		}
	}

}