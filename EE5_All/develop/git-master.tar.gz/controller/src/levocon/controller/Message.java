package levocon.controller;

public class Message {

	private long address; // KNOWN ISSUE: long is signed in Java!
	private int topicId;
	private int messageType;
	private boolean clean;
	private long length;
	private String message;

	public Message(long address, int topicId, int messageType, boolean clean,
			long length) {
		this.address = address;
		this.topicId = topicId;
		this.messageType = messageType;
		this.clean = clean;
		this.length = length;
	}

	public long getAddress() {
		return address;
	}

	public int getTopicId() {
		return topicId;
	}

	public int getMessageType() {
		return messageType;
	}

	public int getClean() {
		return clean ? 1 : 0;
	}

	public long getLength() {
		return length;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}