/*******************************************************************************
*
* FILENAME: process_monitor.c
*
* Description:
* Handles the processes for the entire application
*
*******************************************************************************/

/*-----------------------------------------------------------------------------
        include files
------------------------------------------------------------------------------*/
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <poll.h>
#include <stdint.h>
#include <sys/time.h>
#include <sys/select.h>
#include <sys/types.h>
#include "handle_message_in.h"
#include "handle_message_out.h"
#include "interface.h"
#include "timeout.h"
#include "mqtt_sn_bridge.h"
#include "../mqtt_sn_db/mqtt_sn_db.h"
#include "../connection/coordinator.h"
#include "../connection/mymqtt.h"
#include "sorted_double_linked_list/sorted_double_linked_list.h"
#include "err_handler.h"

/*------------------------------------------------------------------------------
        definitions (defines, typedefs, ...)
------------------------------------------------------------------------------*/

//data base pipe descriptor
int fd_write_db, fd_read_db;

//coordinator pipe descriptor
int up_stream_pipe[2];
int down_stream_pipe[2];

//coordinator global variable
String co_inbuf;
String co_outbuf;
int tty_fds;

//1 to restart -1 to kill default 0
int KILL_COORDINATOR_OR_RESTART;
int KILL_DATABASE_OR_RESTART;
int KILL_SERVER_OR_RESTART;

list_ptr_t list_in, list_out;

#define DEBUG_PRINT(...) \
  do{                                                     \
      printf("In %s in function %s at line %d:", __FILE__,__func__,__LINE__);\
      printf(__VA_ARGS__);\
  } while(0)

#define DEBUG

pthread_mutex_t mutex_write_db = PTHREAD_MUTEX_INITIALIZER;

/*------------------------------------------------------------------------------
        function prototypes
------------------------------------------------------------------------------*/

void run_bridge();
void *handle_output_message_thread(void * p);
void *handle_income_message_thread(void * p);
void *read_message_from_controller(void * p);
void run_coordinator();
//void send_to_bridge();

//coordinator method
void* coordinator_tty_read(void *);
void* coordinator_pipe_read(void *);

/*------------------------------------------------------------------------------
        implementation code
------------------------------------------------------------------------------*/

int main(){

//pid of all the processes.
    pid_t monitor_pid, bridge_pid, coordinator_pid, database_pid;

    int childExitStatus;

    //initialize coordinator pipe
    pipe(up_stream_pipe);
    pipe(down_stream_pipe);


    DEBUG_PRINT("monitor process before create database.\n");

    database_open("mqtt.db",&database_pid,"database_err_message",&fd_write_db,&fd_read_db);

        DEBUG_PRINT("monitor process before create bridge.\n");
    bridge_pid = fork();

    if(bridge_pid == 0){
        run_bridge();
        exit(1);
    }else{

            DEBUG_PRINT("monitor process before create coordinator.\n");
        coordinator_pid = fork();
        if(coordinator_pid == 0){
            run_coordinator();
            exit(1);
        }
    }
        DEBUG_PRINT("monitor process wait for children.\n");
    waitpid(bridge_pid,&childExitStatus,0);
    waitpid(coordinator_pid,&childExitStatus,0);
    waitpid(database_pid,&childExitStatus,0);

    return 0;
}

void run_bridge(){

    close(up_stream_pipe[1]);    //parent only read from up stream
    close(down_stream_pipe[0]);  //parent only write to down stream


    list_in = list_initialization();
    list_out = list_initialization();

    init_timer1();
//    init_timer2();

    int status_flag = fcntl(up_stream_pipe[0],F_GETFL);
    printf("%d\n",status_flag);

    pthread_t handle_in_thread;
    pthread_t handle_out_thread;
    pthread_t read_from_server_thread;

     int *p1, *p2, *p3;

 DEBUG_PRINT("CREATING IN MESSAG THREAD.\n");
    if(pthread_create(&handle_in_thread,NULL,handle_income_message_thread,NULL)){
        perror("create thread unsuccessful\n");
    }

     DEBUG_PRINT("CREATING OUT MESSAG THREAD.\n");

    if(pthread_create(&handle_out_thread,NULL,handle_output_message_thread,NULL)){
        perror("create thread unsuccessful\n");
    }

    char c = 0;
    while(1) {

        read(STDIN_FILENO,&c,1);
        if(c=='q') {             //kill the child
            //kill(pid,SIGUSR1);
        }
        if(c=='s') {
            printf("%s %d\n","parent begin to sending hello...",down_stream_pipe[1]);
            int bytes = write(down_stream_pipe[1],"hello from parent",17);
            printf("parent write %d bytes\n",bytes);
        }
        if(c=='k') {
            //kill(pid,SIGSEGV);
        }

    }

     DEBUG_PRINT("CREATING READ SERVER THREAD.\n");
    if(pthread_create(&read_from_server_thread,NULL,read_message_from_controller,NULL)){
        perror("create thread unsuccessful\n");
    }

    if(pthread_join(handle_in_thread, (void**)&p1)){
        perror("join thread unsuccessful\n");
    }

    if(pthread_join(handle_out_thread, (void**)&p2)){
        perror("join thread unsuccessful\n");
    }

    if(pthread_join(read_from_server_thread, (void**)&p3)){
        perror("join thread unsuccessful\n");
    }

    exit(EXIT_FAILURE);
}

void *handle_output_message_thread(void * p){

    while(1){
        DEBUG_PRINT("WAITING TO READ FROM DATA BASE.\n");
            read_db(&fd_read_db);
        DEBUG_PRINT("FINISH READING FROM DATA BASE.\n");
            sleep(1);
        }
    pthread_exit(NULL);
    return NULL;
}

void *handle_income_message_thread(void * p){

    while(1) {
        printf("%s %d\n","bridge reading pipe: ",up_stream_pipe[0]);
        Byte bytes = 0;
        read(up_stream_pipe[0],&bytes,1);
        if(bytes<=sizeof(MQTT)) {
            printf("%s\n","mqtt data too short...");
            continue;
        }
        printf("brdge is going to receive another %d bytes..",bytes);
        mqtt_ptr_t mqtt = malloc(sizeof(*mqtt));
        void* data =  malloc(bytes-sizeof(*mqtt));
        read(up_stream_pipe[0],mqtt,sizeof(*mqtt));
        read(up_stream_pipe[0], data, bytes-sizeof(*mqtt));
        mqtt->msg = data;

        message_info *message = (message_info *)malloc(size_message_info);
        if(message == NULL){
            err_num = MALLOC_ERR;
            ErrHandler();
            return;
        }

//      DEBUG_INTERFACE_PRINT("i am finishing reading from coordinator111111111111.\n");
        message->data = mqtt->msg;
        message->device_address=(DADDRESS)(mqtt->addr);

        free(mqtt);

        handle_in_message(message);

        printf("address: %ld  message: %s",mqtt->addr, (char*)mqtt->msg);
    }
    pthread_exit(NULL);
    return NULL;
}

void *read_message_from_controller(void * p){

    while(1){
        close(up_stream_pipe[0]);
        close(down_stream_pipe[1]);
        DEBUG_PRINT("WAITING TO READ FROM JAVA.\n");
        read_java();
        DEBUG_PRINT("FINISH READ FROM JAVA.\n");
        sleep(1);
    }
    pthread_exit(NULL);
    return NULL;
}

void run_coordinator() {
//SIGQUIT //CURRENT
//SIGTERM //write  TO ZIGBEE

printf("%s\n","coordinator process running...");

tty_serial_init();
close(up_stream_pipe[0]);
close(down_stream_pipe[1]);

/*
while(1) {

    struct timeval tv;
    fd_set readfds;

    FD_ZERO(&readfds);
    FD_SET(tty_fds,&readfds);
    FD_SET(down_stream_pipe[0],&readfds);

    tv.tv_sec = 5;
    tv.tv_usec = 0;

    int ret = select(2,&readfds,NULL,NULL,&tv);
    if(ret == -1) {
        perror("select");
        exit(EXIT_FAILURE);
    } else if (ret==0) {
        printf("%s\n","5 seconds elapsed, no data available to read...");
        //sleep(5);
    } else {    //nr fds ready to read
        if(FD_ISSET(tty_fds,&readfds))      coordinator_tty_read();
        if(FD_ISSET(down_stream_pipe[0],&readfds)) coordinator_pipe_read();
    }
}  */

pthread_t pth_tty, pth_pipe;
int err;
void* ttyStatus;
void* pipeStatus;

if((err=pthread_create(&pth_tty,NULL,coordinator_tty_read,NULL))!=0) {
    printf("can't create tty thread: %s\n",strerror(err));
    //exit(EXIT_FAILURE);
}
if((err=pthread_create(&pth_pipe,NULL,coordinator_pipe_read,NULL))!=0) {
    printf("can't create pipe thread: %s\n",strerror(err));
    //exit(EXIT_FAILURE);
}

pthread_join(pth_tty,&ttyStatus);
pthread_join(pth_pipe,&pipeStatus);

exit(EXIT_FAILURE);
}

void* coordinator_tty_read(void* arg) {

printf("%s\n","coordinator_tty_read thread running...");

while(1) {
    int bytes = 0;
    bytes = tty_serial_read(tty_fds,co_inbuf);
    printf("received frame length: %d %d %d %d %d\n\n",bytes,co_inbuf[2],co_inbuf[co_inbuf[2]+3],co_inbuf[5],co_inbuf[6]);

    /*
    mqtt_ptr_t mydata = xbee_data_read(&co_inbuf[3],bytes-4); //only the data section, excluding checksum
    if(mydata) {
        Byte nbytes = sizeof(*mydata) + mydata->len;   //actual data bytes
        void* bytestream = malloc(nbytes+1);
        *(Byte*)bytestream = nbytes;
        memcpy(bytestream+1, mydata, sizeof(*mydata));
        memcpy(bytestream+sizeof(*mydata)+1, mydata->msg, mydata->len);
        write(up_stream_pipe[1], bytestream, nbytes+1);
        free(mydata->msg);
        free(mydata);
        free(bytestream);
    }  */

    mqtt_ptr_t mqtt = malloc(sizeof(*mqtt));
    mqtt->addr = 12345;
    mqtt->len = 6;
    mqtt->ts = time(NULL);
    mqtt->msg = malloc(6);
    *(Byte*)mqtt->msg = 6;
    memcpy(mqtt->msg+1, "hello", 5);

    Byte nbytes = sizeof(*mqtt) + mqtt->len;   //actual data bytes
    void* bytestream = malloc(nbytes+1);
    *(Byte*)bytestream = nbytes;
    memcpy(bytestream+1, mqtt, sizeof(*mqtt));
    memcpy(bytestream+sizeof(*mqtt)+1, mqtt->msg, mqtt->len);
    printf("coordinator write %d bytes to pipe...\n",nbytes);
    nbytes = write(up_stream_pipe[1], bytestream, nbytes+1);
    free(mqtt->msg);
    free(mqtt);
    free(bytestream);
    printf("coordinator write %d bytes to pipe...\n",nbytes);
}
/*
int logfds = open("./rdesclog.txt", O_CREAT | O_RDWR | O_APPEND);
int ret = 0, leng = bytes;
String fbuf = co_inbuf;
while (leng>0 && (ret=write(logfds,fbuf,leng))!=0) {
    if(ret==-1) {
        if(errno==EINTR)
            continue;
        perror("wrinting to log file");
    }
    leng -= ret;
    fbuf += ret;
}
if(close(logfds)==-1) perror("close log file");
*/
}

void* coordinator_pipe_read(void* arg) {

printf("%s %d\n","coordinator_pipe_read thread read pipe", down_stream_pipe[0]);

while(1) {
    Byte bytes = 0;
    read(down_stream_pipe[0],&bytes,1);
    if(bytes<=sizeof(MQTT)) {
        printf("%s\n","mqtt data too short...");
        continue ;
    }
    mqtt_ptr_t mqtt = malloc(sizeof(*mqtt));
    void* data =  malloc(bytes-sizeof(*mqtt));
    read(down_stream_pipe[0],mqtt,sizeof(*mqtt));
    read(down_stream_pipe[0], data, bytes-sizeof(*mqtt));
    //mqtt->msg = data;

    if(mqtt->len != *(Byte*)data) {
        printf("%s\n","unmatched length field...");
        continue ;
    }

    uint64_t address = mqtt->addr;
    String mac_addr = malloc(8);
    int i;
    for(i=0; i<8; i++) {
        mac_addr[7-i] = address%256;
        address /= 256;
    }
    char ntw_addr[2] = {0xFF,0xFE};
    String RFData = (String)data;
    //memcpy(RFData,mqtt->msg,mqtt->len);

    bytes = xbee_txReq_frame_assemble(mac_addr,ntw_addr,0,0,RFData,mqtt->len);

    /*
    int logfds = open("./wresclog.txt", O_CREAT | O_RDWR | O_APPEND);
    int ret = 0;
    leng = bytes;
    String fbuf = co_outbuf;
    while (leng>0 && (ret=write(logfds,fbuf,leng))!=0) {
        if(ret==-1) {
            if(errno==EINTR)
                continue;
            perror("wrinting to log file");
        }
        leng -= ret;
        fbuf += ret;
    }
    if(close(logfds)==-1) perror("close log file");
    */

    bytes = tty_serial_write(tty_fds,co_outbuf,bytes);
    printf("write %d bytes... %d\n",bytes,RFData[0]);

    free(data);
    free(mqtt);
    free(mac_addr);
    //free(RFData);
}
}


//void run_coordinator(){

//    //    tty_serial_init();
//    close(up_stream_pipe[0]);
//    close(down_stream_pipe[1]);

//    while(1){
//        send_to_bridge();
//        sleep(8);
//    }
//}

//void send_to_bridge(){
//    mqtt_ptr_t out = (mqtt_ptr_t)malloc(size_MQTT);
//    if(out == NULL){
//        err_num = MALLOC_ERR;
//        ErrHandler();
//        return;
//    }

//    memset(out, 0, size_MQTT);

//    out->addr = 2;
//    out->len = 22;

//    char *mess = (char *)malloc(22);

//    char *temp = mess;

//    *temp = 0x22;
//    *(++temp) = 0x04;
//    *(++temp) = 0x00;
//    *(++temp) = 0x01;
//    *(++temp) = 0x0004;

//    char *client_id1 = (char *)malloc(17);
//    if(out == NULL){
//        err_num = MALLOC_ERR;
//        ErrHandler();
//        return;
//    }
//    snprintf(client_id1,17,"the first test.");

//    char *client_id = client_id1;

//    *(++temp) = *client_id;

//    int i;
//    for(i = 0; i<((out->len)-7);i++){
//        *(++temp) = *(++client_id);
//    }

//    free(client_id1);
//    out->msg = (void *)mess;
//    out->ts = time(NULL);

//    //    temp = mess;
//    //    for(i=0;i<22;i++){
//    //        printf("int send process %d byte is %x\n",i,*((uint8_t *)temp));
//    //        temp++;
//    //    }
//    int8_t written = write(up_stream_pipe[1], out, size_MQTT);
//    if(written != size_MQTT){
//        //TODO do something
//    } else {
//        DEBUG_PRINT("THE NUMBER OF BYTES I SEND IS %d\n\n",out->len);
//        written = write(up_stream_pipe[1], out->msg, out->len);
//        if((unsigned char)written != (out->len)){
//            //TODO do something (the same)
//        } else {
//            //TODO don't free but reuse
//            free(mess);
//        }
//    }
//    DEBUG_PRINT("I finish writing to bridge.\n");
//    free(out);
//}

