/*******************************************************************************
*
* FILENAME: err_handler.c
*
* Description:
* ... Handles errors
*
*******************************************************************************/

/*-----------------------------------------------------------------------------
        include files
------------------------------------------------------------------------------*/

#include "err_handler.h"

/*------------------------------------------------------------------------------
        definitions (defines, typedefs, ...)
------------------------------------------------------------------------------*/

ERR_NUM err_num = NORMAL;

/*------------------------------------------------------------------------------
        implementation code
------------------------------------------------------------------------------*/

void ErrHandler(){
    switch(err_num){
    case NORMAL:
        break;
    case MESSAGE_DB_NULL_ERR:
        printf("the message_db pointer you get is null.\n\n");
        break;
    case MESSAGE_INFO_NULL_ERR:
        printf("the message_info pointer you get is null.\n\n");
        break;
    case DATA_INVALID_ERR:
        printf("the data in message_info is not valid.\n\n");
        break;
    case MALLOC_ERR:
        printf("Error happens when malloc a piece of memory.\n\n");
        break;
    case NO_DEVICE_ERR:
        printf("the device is not connected, but you want to get information from it.\n\n");
        break;
    case UNEXPECTED_ERR:
        printf("the error nomally shouldn't happen, something wrong with the enviroment.\n\n");
        break;
    case ADD_IN_FAILURE:
        printf("you try to add new device in the list_in, but failed.\n\n");
        break;
    case  MALLOC_ERROR:
        printf( "\nCan't malloc memory successfully.\n" );
        break;
    case LIST_EMPTY:
        printf( "\nCan't execute this operation while the list is empty.\n" );
        break;
    case LIST_NOT_EXIST:
        printf( "\nCan't execute this operation while the list is not exist.\n" );
        break;
    case DEVICE_RECONNECT:
        printf( "\nthis device already connected, and you want to reconnect, please check.\n" );
        break;
    case DEVICE_NOTCONNECT:
        printf( "\nthis device is not connected but receive message. please check.\n" );
        break;
    case SASET_ERROR:
        printf("error happens with function sigaction\n\n");
        break;
    case SETITIMER_ERR:
        printf("error happens when you set itimer.\n\n");
        break;
    case DEVICE_NOTCONNECT_ERR:
        printf("the device is not in the list but you want to updata it.\n\n");
        break;
    case PUT_IN_ERR:
        printf("trying to put new device in list_in is not successful.\n\n");
        break;
    case DATA_NULL_ERR:
        printf("the data in the message_info is not valid.\n\n");
        break;
    case INVALID_DATA_ERR:
        printf("Either message_info or data is not valid.\n\n");
        break;
    case MESSAGE_NULL_ERR:
        printf("the message in the message_db is not valid.\n\n");
        break;
    default:
        printf("something strange happens in this system.\n\n");
        break;

    }
}
