/*******************************************************************************
*
* FILENAME: interface.c
*
* Description:
* Implements the bridge's pipes and FIFOs
*
*******************************************************************************/

/*-----------------------------------------------------------------------------
        include files
------------------------------------------------------------------------------*/

#include "interface.h"

/*------------------------------------------------------------------------------
        definitions (defines, typedefs, ...)
------------------------------------------------------------------------------*/

extern int fd_write_db;
extern int fd_read_db;
//extern int fd_write_coordinator[2];
extern int up_stream_pipe[2];
extern int down_stream_pipe[2];

extern pthread_mutex_t mutex_write_db;

//Set the name of fifos between the bridge and Java controller
#define FIFO_TO_JAVA 	"tmp/bridgetojava"
#define FIFO_FROM_JAVA	"tmp/javatobridge"

#define size_MQTT sizeof(MQTT)

#define DEBUG_INTERFACE_PRINT(...) \
  do{                                                     \
      printf("In %s in function %s at line %d:", __FILE__,__func__,__LINE__);\
      printf(__VA_ARGS__);\
  } while(0)

#define DEBUG_INTERFACE

/*------------------------------------------------------------------------------
        implementation code
------------------------------------------------------------------------------*/

int send_controller(MESSAGE *m){
    //Open FIFO (write sync)
    FILE* fifo;
    fifo = fopen(FIFO_TO_JAVA, "w");

    //Write data to FIFO
    fwrite(&(m->address), sizeof(m->address), 1, fifo);
    fwrite(&(m->short_topic_id), sizeof(m->short_topic_id), 1, fifo);
    fwrite(&(m->type), sizeof(m->type), 1, fifo);
    fwrite(&(m->clean), sizeof(m->clean), 1, fifo);
    fwrite(&(m->length), sizeof(m->length), 1, fifo);
    fwrite(&(m->message), sizeof(m->message), 1, fifo);
    fflush(fifo);

    //Error handling
    if(ferror(fifo)){
        printf("I/O error while sending data from bridge to Java through FIFO.");
        fclose(fifo);
        return 1;
    }

    //DEBUG
//	printf("SENDING MESSAGE\n  Address: %d\n  Topic ID: %d\n  Message type: %d\n  Clean: %d\n  Length: %d\n  Message: %s\n\n", m->address, m->short_topic_id, m->type, m->clean, m->length, m->message);

    //Close FIFO and clean up
    fclose(fifo);
    free(m);
    return 0;
}

void read_java(){
    DEBUG_INTERFACE_PRINT("in thread read java 55555555555555555.\n");
    //what will happen if fifo is empty.
    MESSAGE *m_java = read_controller();
    pthread_mutex_lock(&mutex_write_db);
    int written = write(fd_write_db, m_java, size_MESSAGE);
    if(written != size_MESSAGE){
        DEBUG_INTERFACE_PRINT("error when write to database.\n");
    } else {
        if(m_java->length != 0){
            written = write(fd_write_db, m_java->message, m_java->length);
            if(written != m_java->length){
                DEBUG_INTERFACE_PRINT("error when write to database.\n");
            }
            free((void*) m_java->message);
    pthread_mutex_unlock(&mutex_write_db);
        }
    }
    free(m_java);
}


MESSAGE *read_controller(){
    //Open FIFO (read sync)
    FILE* fifo;
    fifo = fopen(FIFO_FROM_JAVA, "r");

    //Read data from FIFO
    MESSAGE* m = (MESSAGE*) malloc(sizeof(MESSAGE));
    fread(&(m->address), sizeof(m->address), 1, fifo);
    fread(&(m->short_topic_id), sizeof(m->short_topic_id), 1, fifo);
    fread(&(m->type), sizeof(m->type), 1, fifo);
    fread(&(m->clean), sizeof(m->clean), 1, fifo);
    fread(&(m->length), sizeof(m->length), 1, fifo);
    fread(&(m->message), sizeof(m->message), 1, fifo);

    //Error handling
    if(ferror(fifo) || feof(fifo)){
        printf("I/O error while receiving data from Java to bridge through FIFO.");
        fclose(fifo);
        return NULL;
    }

    //DEBUG
//	printf("RECEIVED MESSAGE\n  Address: %d\n  Topic ID: %d\n  Message type: %d\n  Clean: %d\n  Length: %d\n  Message: %s\n\n", m->address, m->short_topic_id, m->type, m->clean, m->length, m->message);

    //Close FIFO and return message pointer
    fclose(fifo);
    return m;
}

int send_connection(message_info *message){
    if(message == NULL){
        err_num = MESSAGE_INFO_NULL_ERR;
        ErrHandler();
        return 1;
    }

    if((message->data) == NULL){
            err_num = DATA_INVALID_ERR;
            ErrHandler();
            return 1;
      }
    TYPE type = find_message_type(message);
    printf("the message type is %d:\n", (int)(type));

    mqtt_ptr_t out = (mqtt_ptr_t)malloc(size_MQTT);
    if(out == NULL){
        err_num = MALLOC_ERR;
        ErrHandler();
        return 1;
    }

    memset(out, 0, size_MQTT);

    out->addr = message->device_address;
    out->len = (unsigned char)find_length_of_data(message);
    out->msg = message->data;
    out->ts = time(NULL);

    int written = write(down_stream_pipe[1], out, size_MQTT);
    if(written == -1){
        DEBUG_INTERFACE_PRINT("WRITE TO COORDINATOR ERROR!\n\n");
    } else {
            written = write(down_stream_pipe[1], out->msg, out->len);
            if(written == -1){
                DEBUG_INTERFACE_PRINT("WRITE TO COORDINATOR ERROR!\n\n");
            }
        }

    DEBUG_INTERFACE_PRINT("finish send to coordinator.\n");
    free(out->msg);
    free(out);

    free(message->data);
    free(message);
    message = NULL;
    return 0;
}

void read_connection(){

    int read_from_coordinator;
    MQTT* mqtt = (MQTT*) malloc(size_MQTT);
    if(mqtt == NULL){
        DEBUG_INTERFACE_PRINT("MALLOC ERROR");
    }

   read_from_coordinator = 0;
        DEBUG_INTERFACE_PRINT("FUNCTION BEFORE READ 111111111111 \n\n");
        read_from_coordinator = read(up_stream_pipe[0], mqtt, size_MQTT);
        if(read_from_coordinator == -1){
            DEBUG_INTERFACE_PRINT("read from coordinator error!\n\n");
            DEBUG_INTERFACE_PRINT("THE FILE DESCRIBTOR IN READ FROM COORDINATOR IS    222222  111111111111 \n\n");
            free(mqtt);
            return;
        }

        char *msg = (char *)malloc(mqtt->len);
        if(msg == NULL){
            DEBUG_INTERFACE_PRINT("MALLOC ERROR");
            return;
        }

        DEBUG_INTERFACE_PRINT("NUMBER OF BYTES I WANT TO RECEIVE FOR THE SECOND TIME %d\n\n", mqtt->len);

        read_from_coordinator = read(up_stream_pipe[0], msg, mqtt->len);

        int i;

//        char *temp = (char *)msg;
//        for(i=0;i<22;i++){
//            printf("int receive process %d byte is %x\n",i,*((uint8_t *)temp));
//            temp++;
//        }

  DEBUG_INTERFACE_PRINT("FUNCTION AFTER i READ FOR THE SECOND TIME 111111111111 \n\n");
        if(read_from_coordinator == -1){
            DEBUG_INTERFACE_PRINT("read from coordinator error!\n\n");
            free(msg);
            free(mqtt);
            return;
        }

                 mqtt->msg = msg;
                message_info *message = (message_info *)malloc(size_message_info);
                if(message == NULL){
                    err_num = MALLOC_ERR;
                    ErrHandler();
                    return;
                }

              DEBUG_INTERFACE_PRINT("i am finishing reading from coordinator111111111111.\n");
                message->data = mqtt->msg;
                message->device_address=(DADDRESS)(mqtt->addr);

                free(mqtt);

                handle_in_message(message);
                DEBUG_INTERFACE_PRINT("888888i free message in function read 11111111111111from coordinator.\n");
}


int send_db(MESSAGE *mes){
    pthread_mutex_lock(&mutex_write_db);
    if(mes == NULL){
        err_num = MESSAGE_NULL_ERR;
        ErrHandler();
        return 1;
    }
    printf("the message type is IN SENDDATA FUNCTION %d:\n", (int)(mes->type));
    if(mes->length){
        if(mes->message == NULL){
            err_num = MESSAGE_NULL_ERR;
            ErrHandler();
        }
        else
        {
        //   pthread_mutex_lock(&mutex_write_db);
            int written = write(fd_write_db, mes, size_MESSAGE);
            if(written != size_MESSAGE){
                DEBUG_INTERFACE_PRINT("error when write to database.\n");
            } else {
                if(mes->length != 0){
                    written = write(fd_write_db, mes->message, mes->length);
                    if(written != mes->length){
                        DEBUG_INTERFACE_PRINT("error when write to database.\n");
                    }
                    free((void*) mes->message);
         //   pthread_mutex_unlock(&mutex_write_db);
                }
            }
        }
      }
    free(mes);
    mes = NULL;
    pthread_mutex_unlock(&mutex_write_db);
    return 0;
}

void read_db(){

    DEBUG_INTERFACE_PRINT("i am start read from database.\n");

//    typeout++;
//    if(typeout > 20){
//        typeout = 0;
//    }
//    db_create_message(&m,5,0,0,1,typeout,0,0,3,0,0,0,0,0,0,NULL);


    MESSAGE* m = (MESSAGE*) malloc(sizeof(MESSAGE));
    if(m == NULL){
        printf("ERROR: malloc did not work! crashing,...\n");
        exit(0);
    }

    int bytes_read = 0;

    bytes_read = read(fd_read_db, m, sizeof(MESSAGE));

    if(bytes_read == -1){
        perror("1111111111");
        DEBUG_INTERFACE_PRINT("read error!\n\n");
    }

    if(m->length != 0){
        void* data = malloc(m->length);
        bytes_read = read(fd_read_db, data, m->length);
        if(bytes_read == -1){
            DEBUG_INTERFACE_PRINT("read error!\n\n");
        }
        m->message = data;
    }

    DEBUG_INTERFACE_PRINT("i am start handle output message.\n");
    handle_out_message(m);
    DEBUG_INTERFACE_PRINT("i am finish handle output message in function read from database.\n");
}
