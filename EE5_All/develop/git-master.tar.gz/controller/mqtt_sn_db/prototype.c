#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>


#define ERROR uint32_t
#define DB_OK 0

/* writes the parameters to memory and sets the first_byte to the first empty byte */
static ERROR db_request_write_line(void** first_byte, uint32_t time, uint32_t length_client_id, void* client_id, uint32_t length_message, void* message){
	
	void* cursor = *fist_byte;
	uint32_t i = 0;

	*(uint32_t*) cursor = time;
	cursor += sizeof(uint32_t);

	*(uint32_t*) cursor = length_client_id;
	cursor += sizeof(uint32_t);

	for(i = 0; i<length_client_id; i++){
		*((uint8_t*) cursor + i) = *((uint8_t*) client_id +i);
	}
	cursor += length_client_id; 

	*(uint32_t*) cursor = length_message;
	cursor += sizeof(uint32_t);

	for(i = 0; i<length_message; i++){
		*((uint8_t*) cursor + i) = *((uint8_t*) client_id +i);
	}
	cursor += length_message;
	return DB_OK;
}
