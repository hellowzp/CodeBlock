# Dependencies
The web application requires the following dependencies:
* db_setup.sql: run in a database called ee5
* Compiled CSS files: css/
* jquery-1.10.2.min.js: js/vendor/
* modernizr-2.6.2.min.js: js/vendor/
* morris.js Bower library: bower_components/
* raphael Bower library: bower_components/
