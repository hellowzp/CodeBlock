<?php 

//Connect to the database
$url = "localhost";
$user = "ee5";
$pass = "a*nGC]YE?UC{";
$db = "ee5";
mysql_connect($url, $user, $pass);
mysql_select_db($db);

//Print out the properties for a morris.js line graph
function getGraphJs($dataTable, $dataColumn, $sensorArray){
	
	//Build data array
	$data = array();
	while($sensor = current($sensorArray)){
		$sensorAddress = explode(".", $sensor);
		$q = mysql_query("SELECT timestamp AS 't', {$dataColumn} AS 's{$sensor}' FROM {$dataTable} WHERE gridId = '{$sensorAddress[0]}' AND deviceId = '{$sensorAddress[1]}' AND sensorId = '{$sensorAddress[2]}'") or die(mysql_error());
		while($r = mysql_fetch_assoc($q)){
			if($array_match_pos = array_search_recursive("{$r[t]}",$data)){
				//If the timestamp is already present, add the sensor data to the existing sub-array within the data-array
				$data[$array_match_pos]["s{$sensor}"] = $r["s{$sensor}"];
			} else{
				//Else, add a new sub-array to the data-array
				array_push($data, $r);
			}
		}
		next($sensorArray);
	}
	
	//Print out properties
	$json = json_encode($data);
	echo "data:{$json},";
	echo "xkey:'t',";
	echo "ykeys:['s".implode("','s",$sensorArray)."'],";
	echo "labels:['Sensor ".implode("','Sensor ",$sensorArray)."'],";

}

//Recursive array search. Returns the index of the array that contains the array in which the needle is found. Returns false if no matches are found.
function array_search_recursive($needle, $haystack){
	$i = 0;
	while($current_array = current($haystack)){
		if(array_search($needle, $current_array)){
			return $i;
		} else{
			$i++;
			next($haystack);
		}
	}
	return false;
}

?>