#include <iostream>

using namespace std;

class A {
    public:
    int x;
    
    A(const A& oth) {
        cout << "copy ctr " << oth.x << x << endl;
    }
    
    A() {
        cout << "ctra " << x << endl;
        x = 0;
    }
    
    ~A() {
        cout << "dtra" << endl;
    }
};

class B {
    A a;
    public:
    B() {
//        cout << "ctr" << a << endl;
        cout << "ctrb " << a.x << endl;
    }
    
    ~B() {
        cout << "dtrb" << endl;
    }
};

int main()
{
   cout << "Hello World" << endl; 
   
   A a;
   {A& c = a;}
   A b = a;
   
   B bb;
   
   return 0;
}

