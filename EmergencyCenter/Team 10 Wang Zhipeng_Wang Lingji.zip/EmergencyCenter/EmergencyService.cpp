#include "EmergencyService.h"

EmergencyService::~EmergencyService() {

}
