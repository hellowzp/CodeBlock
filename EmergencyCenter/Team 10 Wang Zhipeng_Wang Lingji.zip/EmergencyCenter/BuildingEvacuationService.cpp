#include "BuildingEvacuationService.h"
#include <iostream>


void BuildingEvacuationService::performService() {
	std::cout << "BuildingEvacuationService performed!" << std::endl;
}

BuildingEvacuationService::~BuildingEvacuationService() {

}


