#include "ServiceManager.h"

void ServiceManager::activate() {
	// TODO - implement ServiceManager::activate
	throw "Not yet implemented";
}

void ServiceManager::deactivate() {
	// TODO - implement ServiceManager::deactivate
	throw "Not yet implemented";
}

//void ServiceManager::test(Component comp) {
//	// TODO - implement ServiceManager::test
//	throw "Not yet implemented";
//}
