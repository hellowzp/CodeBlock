#include "EmergencyService.h"

class BuildingEvacuationService : public EmergencyService {

public:
    ~BuildingEvacuationService();

    void performService();
};
